
import math

# ---------- y(tau) per regime ----------

def y_underdamped(zeta, tau):
    # y = z'(tau); z(tau) = e^{-zeta tau} [cos(ω_d tau) + (zeta/ω_d) sin(ω_d tau)]
    if not (0.0 <= zeta < 1.0):
        raise ValueError("y_underdamped requires 0 <= zeta < 1")
    omega_d = math.sqrt(1.0 - zeta*zeta)
    return - math.exp(-zeta * tau) * math.sin(omega_d * tau) / omega_d


def y_crit(tau):
    # z(tau) = e^{-tau}(1+tau) → y = z'
    return - tau * math.exp(-tau)


def y_overdamped(zeta, tau):
    # y = z'(tau) with alpha = sqrt(zeta^2 - 1)
    if not (zeta > 1.0):
        raise ValueError("y_overdamped requires zeta > 1")
    alpha = math.sqrt(zeta*zeta - 1.0)
    e = math.exp(-zeta * tau)
    a_p = (zeta + alpha) * math.exp(+alpha * tau)
    a_m = (zeta - alpha) * math.exp(-alpha * tau)
    return - (e * (a_p + a_m)) / (2.0 * alpha)


# ---------- Closed-form Σ for underdamped / critical ----------

def sigma_underdamped(zeta, Theta):
    """
    Σ(ζ) = 2 ζ ∫_0^Θ y(τ)^2 dτ, with y_underdamped.
    Closed form from Appendix C.
    """
    if not (0.0 <= zeta < 1.0):
        raise ValueError("sigma_underdamped requires 0 <= zeta < 1")
    omega_d = math.sqrt(1.0 - zeta*zeta)
    e = math.exp(-2.0 * zeta * Theta)
    num1 = (1.0 - e) / (2.0 * zeta) if zeta > 0.0 else Theta  # continuous as zeta→0+
    num2 = e * (zeta * math.sin(2.0 * omega_d * Theta) + omega_d * math.cos(2.0 * omega_d * Theta)) + omega_d
    denom2 = 2.0 * (zeta*zeta + omega_d*omega_d)  # = 2
    return (zeta / (omega_d * omega_d)) * (num1 - (num2 / denom2))


def sigma_crit(Theta):
    """
    Σ(1) = 2 ∫_0^Θ τ^2 e^{-2τ} dτ
    """
    e = math.exp(-2.0 * Theta)
    return 2.0 * ( -0.5 * Theta*Theta * e - 0.5 * Theta * e - 0.25 * e + 0.25 )


# ---------- Adaptive Simpson integrator for overdamped Σ ----------

def _simpson(f, a, b):
    c = 0.5 * (a + b)
    h = b - a
    return (h / 6.0) * (f(a) + 4.0*f(c) + f(b))

def _adaptive_simpson(f, a, b, eps, whole, depth, max_depth=30):
    c = 0.5 * (a + b)
    left  = _simpson(f, a, c)
    right = _simpson(f, c, b)
    if depth >= max_depth:
        return left + right
    if abs(left + right - whole) <= 15.0 * eps:
        return left + right + (left + right - whole) / 15.0
    return (_adaptive_simpson(f, a, c, eps/2.0, left, depth+1, max_depth) +
            _adaptive_simpson(f, c, b, eps/2.0, right, depth+1, max_depth))

def adaptive_integrate(f, a, b, eps=1e-9):
    whole = _simpson(f, a, b)
    return _adaptive_simpson(f, a, b, eps, whole, 0)

def sigma_overdamped(zeta, Theta, tol=1e-9):
    """
    Overdamped cost via robust numeric integration of y(τ)^2.
    Σ(ζ) = 2 ζ ∫_0^Θ y(τ)^2 dτ, y = y_overdamped(ζ, τ).
    """
    if not (zeta > 1.0):
        raise ValueError("sigma_overdamped requires zeta > 1")
    def f(tau):
        y = y_overdamped(zeta, tau)
        return y*y
    integral = adaptive_integrate(f, 0.0, Theta, eps=tol)
    return 2.0 * zeta * integral


# ---------- Terminal information I(ζ) = 1 - z(Θ)^2 ----------

def z_underdamped(zeta, tau):
    omega_d = math.sqrt(1.0 - zeta*zeta)
    return math.exp(-zeta * tau) * (math.cos(omega_d * tau) + (zeta/omega_d) * math.sin(omega_d * tau))

def z_crit(tau):
    return math.exp(-tau) * (1.0 + tau)

def z_overdamped(zeta, tau):
    alpha = math.sqrt(zeta*zeta - 1.0)
    e = math.exp(-zeta * tau)
    return (e / (2.0 * alpha)) * ((zeta + alpha) * math.exp(+alpha * tau) - (zeta - alpha) * math.exp(-alpha * tau))

def terminal_info(zeta, Theta):
    if zeta < 1.0:
        z = z_underdamped(zeta, Theta)
    elif zeta == 1.0:
        z = z_crit(Theta)
    else:
        z = z_overdamped(zeta, Theta)
    return 1.0 - z*z


# ---------- Convenience wrapper for Σ in all regimes ----------

def sigma_all(zeta, Theta, tol=1e-9):
    if zeta < 1.0:
        return sigma_underdamped(zeta, Theta)
    elif zeta == 1.0:
        return sigma_crit(Theta)
    else:
        return sigma_overdamped(zeta, Theta, tol=tol)
